import os
import tempfile
import uuid
import json
import requests
from pptx import Presentation
from pptx.util import Inches, Pt
from openai import AzureOpenAI
from utils import get_env, safe_json_load, logger, now_ts
from search_utils import semantic_search
from azure_blob_utils import upload_ppt_to_blob, upload_json_to_blob

client = AzureOpenAI(
    azure_endpoint=get_env("OPENAI_API_BASE", required=True),
    api_key=get_env("OPENAI_API_KEY", required=True),
    api_version=get_env("OPENAI_API_VERSION", "2024-05-01-preview")
)

CHAT_MODEL = get_env("CHAT_MODEL", "gpt-4o")
DALLE_MODEL = get_env("DALLE_MODEL", "dall-e-3")

def call_llm_plan(prompt: str, style: str):
    sys_prompt = ("You are a concise presentation assistant. Output only JSON: a list of slides, " 
                  "each slide is {\"title\":\"...\", \"bullets\": [..] }.")
    usr = f"Create a 5-8 slide outline for: {prompt}. Style: {style}."
    try:
        resp = client.chat.completions.create(
            model=CHAT_MODEL,
            messages=[{"role":"system","content":sys_prompt},{"role":"user","content":usr}],
            max_tokens=800
        )
        text = resp.choices[0].message.content
        plan = safe_json_load(text)
        if not plan:
            logger.warning("LLM returned non-JSON; using fallback outline")
            return [{"title":"Intro","bullets":["Overview"]},{"title":"Summary","bullets":["Key takeaways"]}]
        return plan
    except Exception as e:
        logger.exception(f"Plan generation failed: {e}")
        return [{"title":"Intro","bullets":["Overview"]},{"title":"Summary","bullets":["Key takeaways"]}]

def call_dalle(prompt: str):
    try:
        resp = client.images.generate(model=DALLE_MODEL, prompt=prompt, size="1024x1024")
        url = resp.data[0].url
        r = requests.get(url)
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".png")
        tmp.write(r.content)
        tmp.close()
        return tmp.name
    except Exception as e:
        logger.warning(f"DALL·E generation failed: {e}")
        return None

def build_ppt(slides, include_images):
    prs = Presentation()
    for s in slides:
        layout = prs.slide_layouts[1] if len(prs.slide_layouts) > 1 else prs.slide_layouts[0]
        slide = prs.slides.add_slide(layout)
        try:
            slide.shapes.title.text = s.get("title", "")
        except Exception:
            pass
        try:
            tf = slide.placeholders[1].text_frame
            tf.clear()
            for b in s.get("bullets", []):
                p = tf.add_paragraph()
                p.text = b
                p.font.size = Pt(18)
        except Exception:
            pass
        if include_images and s.get("image_path"):
            try:
                slide.shapes.add_picture(s["image_path"], Inches(0.5), Inches(3.0), width=Inches(8))
            except Exception as e:
                logger.debug(f"Could not add image: {e}")
    out = os.path.join(tempfile.gettempdir(), f"generated_presentation_{uuid.uuid4().hex[:8]}.pptx")
    prs.save(out)
    return out

def generate_presentation(prompt: str, style: str = "Auto", include_images: bool = False, top_k: int = 3, tag_filters: list = None):
    plan = call_llm_plan(prompt, style)
    slides = []
    used_slide_ids = []
    for p in plan:
        title = p.get("title","Slide")
        refs = semantic_search(title, top_k=top_k, tags=tag_filters)
        bullets = [r.get("text","")[:200] for r in refs][:3]
        slide = {"title": title, "bullets": bullets}
        if include_images:
            img = call_dalle(f"Professional illustration for slide titled '{title}'. Keywords: {';'.join(bullets)[:150]}")
            if img:
                slide["image_path"] = img
        slides.append(slide)
        for r in refs:
            sid = r.get("slide_id") or r.get("id")
            if sid:
                used_slide_ids.append(sid)
    out_path = build_ppt(slides, include_images)
    file_name = f"generated_{uuid.uuid4().hex[:8]}.pptx"
    upload_ppt_to_blob(out_path, file_name)
    log = {
        "timestamp": now_ts(),
        "prompt": prompt,
        "style": style,
        "include_images": include_images,
        "tag_filters": tag_filters or [],
        "used_slide_ids": used_slide_ids,
        "generated_file": file_name
    }
    upload_json_to_blob(json.dumps(log, indent=2).encode("utf-8"), blob_name=f"logs/{file_name}.json")
    return out_path, log
