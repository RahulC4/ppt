import os
import json
import logging
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
logging.basicConfig(level=LOG_LEVEL, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
logger = logging.getLogger("ai-ppt-generator-chroma")

def get_env(name, default=None, required=False):
    val = os.getenv(name, default)
    if required and (val is None or val == ""):
        logger.error(f"Missing required environment variable: {name}")
        raise EnvironmentError(f"Missing env var: {name}")
    return val

def safe_json_load(s):
    if not s:
        return None
    s = s.strip()
    starts = [s.find(ch) for ch in ['{', '['] if s.find(ch) != -1]
    if not starts:
        return None
    start = min(starts)
    try:
        return json.loads(s[start:])
    except Exception as e:
        logger.warning(f"safe_json_load failed: {e}")
        return None

def now_ts():
    return datetime.utcnow().isoformat() + "Z"

def get_embedding_dim(model_name):
    """Return embedding dim for known models; fallback to EMBEDDING_DIM env var."""
    if not model_name:
        try:
            return int(get_env("EMBEDDING_DIM", 1536))
        except Exception:
            return 1536
    mn = model_name.lower()
    if "3-small" in mn:
        return 1536
    if "3-large" in mn:
        return 3072
    # fallback to env var
    try:
        return int(get_env("EMBEDDING_DIM", 1536))
    except Exception:
        return 1536
