import os 
from openai import AzureOpenAI
from chromadb import PersistentClient
from utils import get_env, logger, get_embedding_dim

# === CONFIG ===
EMBEDDING_MODEL = get_env("EMBEDDING_MODEL", "text-embedding-3-small")
CHROMA_PERSIST_DIR = get_env("CHROMA_PERSIST_DIR", "./chroma_db")

# === AZURE OPENAI CLIENT ===
client = AzureOpenAI(
    azure_endpoint=get_env("OPENAI_API_BASE", required=True),
    api_key=get_env("OPENAI_API_KEY", required=True),
    api_version=get_env("OPENAI_API_VERSION", "2024-05-01-preview")
)

# === CHROMA CLIENT ===
chroma_client = PersistentClient(path=CHROMA_PERSIST_DIR)
collection = chroma_client.get_collection("ppt_slides")

EMBEDDING_DIM = get_embedding_dim(EMBEDDING_MODEL)


def get_embedding(text):
    """Generate a single embedding vector for search."""
    try:
        resp = client.embeddings.create(model=EMBEDDING_MODEL, input=text)
        return resp.data[0].embedding
    except Exception as e:
        logger.exception(f"Embedding failed: {e}")
        return None


def semantic_search(query, top_k=4, tags=None):
    """
    Perform semantic search in Chroma for a given query.
    If tags are provided, filter slides whose metadata tags contain that substring.
    """
    emb = get_embedding(query)
    if emb is None:
        return []

    # Build filter (tags stored as comma-separated strings)
    filters = None
    if tags:
        # Convert to OR-based filter for substring match
        filters = {"$or": [{"tags": {"$contains": t}} for t in tags]}

    try:
        if filters:
            results = collection.query(query_embeddings=[emb], n_results=top_k, where=filters)
        else:
            results = collection.query(query_embeddings=[emb], n_results=top_k)

        out = []
        ids = results.get("ids", [[]])[0]
        metadatas = results.get("metadatas", [[]])[0]
        distances = results.get("distances", [[]])[0]
        docs = results.get("documents", [[]])[0]

        for i in range(len(ids)):
            out.append({
                "id": ids[i],
                "ppt_name": metadatas[i].get("ppt_name"),
                "slide_id": metadatas[i].get("slide_id"),
                "title": metadatas[i].get("title"),
                "text": docs[i],
                "tags": metadatas[i].get("tags"),
                "score": distances[i]
            })
        return out

    except Exception as e:
        logger.exception(f"Chroma query failed: {e}")
        return []
